todo:
========================================================================
- docs from database?
- backup database schema/data
- fix favicon.ico getting 404'd
- improve install/setup documentation in README.md
